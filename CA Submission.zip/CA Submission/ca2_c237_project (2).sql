-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2024 at 12:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ca2_c237_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `foodcourts`
--

CREATE TABLE `foodcourts` (
  `foodcourtID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `foodcourts`
--

INSERT INTO `foodcourts` (`foodcourtID`, `name`, `location`, `image`) VALUES
(1, 'North', 'Beside E6 Building', 'noImage.png'),
(14, 'Mohamed Syauqii', '4w', 'apples.png'),
(15, 'Brocolli', 'Beside E3 Building', 'broccoli.png');

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `foodID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stallID` int(11) DEFAULT NULL,
  `availability` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `foods`
--

INSERT INTO `foods` (`foodID`, `name`, `price`, `stallID`, `availability`) VALUES
(1, 'Tteokbokki', 5.80, 1, ''),
(13, 'Tteokbokki', -1.00, 24, 'available'),
(16, 'Cwosia', -1.00, 24, '');

-- --------------------------------------------------------

--
-- Table structure for table `stalls`
--

CREATE TABLE `stalls` (
  `stallID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `foodcourtID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stalls`
--

INSERT INTO `stalls` (`stallID`, `name`, `image`, `foodcourtID`) VALUES
(1, '', '/images/placeholder', NULL),
(4, '96 Beef', NULL, NULL),
(5, '96 Beef', NULL, NULL),
(6, '96 Beef', NULL, NULL),
(7, '96 Beef', NULL, NULL),
(8, '96 Beef', NULL, NULL),
(9, '96 Beef', NULL, NULL),
(10, '96 Beef', NULL, NULL),
(13, '', NULL, NULL),
(24, '96 Stalls', 'noImage.png', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `foodcourts`
--
ALTER TABLE `foodcourts`
  ADD PRIMARY KEY (`foodcourtID`);

--
-- Indexes for table `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`foodID`),
  ADD KEY `stallID` (`stallID`);

--
-- Indexes for table `stalls`
--
ALTER TABLE `stalls`
  ADD PRIMARY KEY (`stallID`),
  ADD KEY `foodcourtID` (`foodcourtID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `foodcourts`
--
ALTER TABLE `foodcourts`
  MODIFY `foodcourtID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `foods`
--
ALTER TABLE `foods`
  MODIFY `foodID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `stalls`
--
ALTER TABLE `stalls`
  MODIFY `stallID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `foods`
--
ALTER TABLE `foods`
  ADD CONSTRAINT `foods_ibfk_1` FOREIGN KEY (`stallID`) REFERENCES `stalls` (`stallID`);

--
-- Constraints for table `stalls`
--
ALTER TABLE `stalls`
  ADD CONSTRAINT `stalls_ibfk_1` FOREIGN KEY (`foodcourtID`) REFERENCES `foodcourts` (`foodcourtID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
